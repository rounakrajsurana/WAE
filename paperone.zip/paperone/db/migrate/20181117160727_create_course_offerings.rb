class CreateCourseOfferings < ActiveRecord::Migration[5.2]
  def change
    create_table :course_offerings do |t|
      t.references :course, foreign_key: true
      t.date :year
      t.string :semester

      t.timestamps
    end
  end
end
