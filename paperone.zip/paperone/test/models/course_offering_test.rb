require 'test_helper'

class CourseOfferingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
