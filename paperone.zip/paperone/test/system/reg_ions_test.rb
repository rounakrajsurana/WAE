require "application_system_test_case"

class RegIonsTest < ApplicationSystemTestCase
  setup do
    @reg_ion = reg_ions(:one)
  end

  test "visiting the index" do
    visit reg_ions_url
    assert_selector "h1", text: "Reg Ions"
  end

  test "creating a Reg ion" do
    visit reg_ions_url
    click_on "New Reg Ion"

    fill_in "Course Offering", with: @reg_ion.course_offering_id
    fill_in "Grade", with: @reg_ion.grade
    fill_in "User", with: @reg_ion.user_id
    click_on "Create Reg ion"

    assert_text "Reg ion was successfully created"
    click_on "Back"
  end

  test "updating a Reg ion" do
    visit reg_ions_url
    click_on "Edit", match: :first

    fill_in "Course Offering", with: @reg_ion.course_offering_id
    fill_in "Grade", with: @reg_ion.grade
    fill_in "User", with: @reg_ion.user_id
    click_on "Update Reg ion"

    assert_text "Reg ion was successfully updated"
    click_on "Back"
  end

  test "destroying a Reg ion" do
    visit reg_ions_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Reg ion was successfully destroyed"
  end
end
