require 'test_helper'

class RegIonsControllerTest < ActionDispatch::IntegrationTest
  setup do
    @reg_ion = reg_ions(:one)
  end

  test "should get index" do
    get reg_ions_url
    assert_response :success
  end

  test "should get new" do
    get new_reg_ion_url
    assert_response :success
  end

  test "should create reg_ion" do
    assert_difference('RegIon.count') do
      post reg_ions_url, params: { reg_ion: { course_offering_id: @reg_ion.course_offering_id, grade: @reg_ion.grade, user_id: @reg_ion.user_id } }
    end

    assert_redirected_to reg_ion_url(RegIon.last)
  end

  test "should show reg_ion" do
    get reg_ion_url(@reg_ion)
    assert_response :success
  end

  test "should get edit" do
    get edit_reg_ion_url(@reg_ion)
    assert_response :success
  end

  test "should update reg_ion" do
    patch reg_ion_url(@reg_ion), params: { reg_ion: { course_offering_id: @reg_ion.course_offering_id, grade: @reg_ion.grade, user_id: @reg_ion.user_id } }
    assert_redirected_to reg_ion_url(@reg_ion)
  end

  test "should destroy reg_ion" do
    assert_difference('RegIon.count', -1) do
      delete reg_ion_url(@reg_ion)
    end

    assert_redirected_to reg_ions_url
  end
end
