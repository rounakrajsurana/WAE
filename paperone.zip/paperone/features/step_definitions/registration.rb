Given("I am a {string}") do |string|
    case string  
    when 'student'
     @user = FactoryBot.create :student
    end
  end
  
  Given("I want to make a registration") do
    @Registration = FactoryBot.build :Registration
    @Registration.user = @user 
    @Registration.course_offering  = CourseOffering.find_by_id(2)
  end
  
  Given("I am logged in") do
    visit '/users/sign_in'
    fill_in 'Email', with: @user.email
    fill_in 'Password', with: @user.password
    click_button 'Log in'
  end
  
  When("I visit {string}") do |string|
    visit string
  end
  
  Then("I should see {string} link") do |string|
    expect(page).to have_link string
  end
  
  When("I click on {string} link") do |string|
    find_link(string).click
  end
  
  Then("I should see {string} form") do |string|
    expect(page).to have_content string
  end
  
  When("I fill in the reg_ion form") do
    fill_in "Course offering", with: @Registration.course_offering_id
    select @Registration.grade , :from => "Grade"
    click_button 'Create Reg ion'
  end
  
  Then("I should see my Registration") do
    save_and_open_page
    pending # Write code here that turns the phrase above into concrete actions
  end