
FactoryBot.define do
    factory :student, class: User do
        email { "1@ait.asia" }
        password { "password" }
        password_confirmation { "password" }
    end
    
    factory :Registration, class: RegIon do
        course_offering_id { 2}
        grade {'A'}
    end
    
end