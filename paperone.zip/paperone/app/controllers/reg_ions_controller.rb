class RegIonsController < ApplicationController
  before_action :set_reg_ion, only: [:show, :edit, :update, :destroy]

  # GET /reg_ions
  # GET /reg_ions.json
  def index
    @reg_ions = RegIon.all
  end

  # GET /reg_ions/1
  # GET /reg_ions/1.json
  def show
  end

  # GET /reg_ions/new
  def new
    @reg_ion = RegIon.new
  end

  # GET /reg_ions/1/edit
  def edit
  end

  # POST /reg_ions
  # POST /reg_ions.json
  def create
    @reg_ion = RegIon.new(reg_ion_params)

    respond_to do |format|
      if @reg_ion.save
        format.html { redirect_to @reg_ion, notice: 'Reg ion was successfully created.' }
        format.json { render :show, status: :created, location: @reg_ion }
      else
        format.html { render :new }
        format.json { render json: @reg_ion.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /reg_ions/1
  # PATCH/PUT /reg_ions/1.json
  def update
    respond_to do |format|
      if @reg_ion.update(reg_ion_params)
        format.html { redirect_to @reg_ion, notice: 'Reg ion was successfully updated.' }
        format.json { render :show, status: :ok, location: @reg_ion }
      else
        format.html { render :edit }
        format.json { render json: @reg_ion.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /reg_ions/1
  # DELETE /reg_ions/1.json
  def destroy
    @reg_ion.destroy
    respond_to do |format|
      format.html { redirect_to reg_ions_url, notice: 'Reg ion was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_reg_ion
      @reg_ion = RegIon.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def reg_ion_params
      params.require(:reg_ion).permit(:user_id, :course_offering_id, :grade)
    end
end
