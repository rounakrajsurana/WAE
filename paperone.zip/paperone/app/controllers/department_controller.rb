class DepartmentController < ApplicationController
  def index
  end
end
