class RegIon < ApplicationRecord
  belongs_to :user, :optional => true
  belongs_to :course_offering
end
