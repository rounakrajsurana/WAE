class CourseOffering < ApplicationRecord
  belongs_to :course, :optional => true
  has_many :registrations
  #enum semester: [:august, :january, :june]
  def to_s
    "#{self.course_id}"
end
end
