class Comment < ApplicationRecord
  belongs_to :request
end
