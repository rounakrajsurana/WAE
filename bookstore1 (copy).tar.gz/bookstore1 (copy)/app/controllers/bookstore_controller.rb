class BookstoreController < ApplicationController
end
