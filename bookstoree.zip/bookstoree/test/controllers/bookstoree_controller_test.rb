require 'test_helper'

class BookstoreeControllerTest < ActionDispatch::IntegrationTest

  include Devise::Test::IntegrationHelpers

  test "should get index" do
    get bookstoree_index_url
    assert_response :success
  end

end
